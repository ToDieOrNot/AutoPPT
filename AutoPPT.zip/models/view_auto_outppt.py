#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：AutoPPT
@File    ：view_auto_outppt.py
@Date    ：2025/7/23 15:18
@Descrip ：
'''
