#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：AutoPPT
@File    ：view_demo_curd.py
@Date    ：2025/7/24 9:08
@Descrip ：
'''


import os
from models.config_read import read_env


def obj_searchall():
    pass


def obj_create(data):
    pass


def obj_update(data):
    pass


def obj_delete(data):
    pass
