#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：AutoPPT
@File    ：view_course_curd.py
@Date    ：2025/7/23 10:33
@Descrip ：
'''


import os
from models.config_read import read_env


def obj_searchall():
    dict_env = read_env()
    courses_datas = []
    dir_course = dict_env.get("dir_course")


def obj_create():
    pass


def obj_delete():
    pass