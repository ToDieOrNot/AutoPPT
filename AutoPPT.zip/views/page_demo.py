#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：AutoPPT
@File    ：page_demo.py
@Date    ：2025/7/23 15:22
@Descrip ：
'''
from views.page_public import batch_remove_scopes
from pywebio.input import *
from pywebio.output import *


def refresh_table():
    pass


def create_auto_outppt():
    pass


def update_auto_outppt(index):
    pass


def delete_auto_outppt(index):
    pass


def load_interface():
    batch_remove_scopes()


def page_auto_outppt():
    load_interface()
